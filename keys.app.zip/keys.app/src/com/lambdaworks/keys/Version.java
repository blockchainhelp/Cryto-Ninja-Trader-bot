// Copyright (C) 2013 - Will Glozer. All rights reserved.

package com.lambdaworks.keys;

public class Version {
    public final String openssl;

    public Version(String openssl) {
        this.openssl = openssl;
    }
}
